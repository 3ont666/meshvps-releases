package dns

import (
	"github.com/sagernet/sing/common/buf"

	"github.com/miekg/dns"
)

func TruncateDNSMessage(request *dns.Msg, response *dns.Msg, frontHeadroom int, rearHeadroom int) (*buf.Buffer, error) {
	maxLen := 512
	if edns0Option := request.IsEdns0(); edns0Option != nil {
		if udpSize := int(edns0Option.UDPSize()); udpSize > 512 {
			maxLen = udpSize
		}
	}
	responseLen := response.Len()
	compressedResponse := *response
	compressedResponse.Compress = true
	if compressedResponse.Len() > maxLen {
		compressedResponse = *response.Copy()
		compressedResponse.Truncate(maxLen)
	}
	buffer := buf.NewSize(frontHeadroom + responseLen + 1 + rearHeadroom)
	buffer.Resize(frontHeadroom, 0)
	rawMessage, err := compressedResponse.PackBuffer(buffer.FreeBytes())
	if err != nil {
		buffer.Release()
		return nil, err
	}
	buffer.Truncate(len(rawMessage))
	return buffer, nil
}
