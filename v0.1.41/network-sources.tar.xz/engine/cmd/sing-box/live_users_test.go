package main

import (
	"encoding/json"
	"errors"
	"github.com/sagernet/sing-box/adapter"
	"net/http/httptest"
	"strings"
	"testing"
)

type testUsers struct {
	adapter.Inbound
	applied int
}

func (u *testUsers) PrepareUserUpdate(data []byte) (func(), error) {
	var v []string
	if json.Unmarshal(data, &v) != nil {
		return nil, errors.New("bad users")
	}
	return func() { u.applied++ }, nil
}

type testInbounds struct {
	adapter.InboundManager
	entries map[string]adapter.Inbound
}

func (m *testInbounds) Get(tag string) (adapter.Inbound, bool) { v, ok := m.entries[tag]; return v, ok }
func TestLiveUpdateValidatesWholeBatch(t *testing.T) {
	first, second := &testUsers{}, &testUsers{}
	control := &usersControl{manager: &testInbounds{entries: map[string]adapter.Inbound{"one": first, "two": second}}}
	for _, entry := range []struct {
		body   string
		status int
		count  int
	}{
		{`{"version":1,"inbounds":[{"tag":"one","users":["new"]},{"tag":"two","users":42}]}`, 400, 0},
		{`{"version":1,"inbounds":[{"tag":"one","users":[]},{"tag":"one","users":[]}]}`, 400, 0},
		{`{"version":2,"inbounds":[{"tag":"one","users":[]}]}`, 400, 0},
		{`{"version":1,"inbounds":[{"tag":"one","users":["new"]},{"tag":"two","users":["new"]}]}`, 200, 1},
	} {
		req := httptest.NewRequest("POST", "/v1/users", strings.NewReader(entry.body))
		w := httptest.NewRecorder()
		control.ServeHTTP(w, req)
		if w.Code != entry.status || first.applied != entry.count || second.applied != entry.count {
			t.Fatalf("status=%d applied=%d,%d", w.Code, first.applied, second.applied)
		}
	}
}
