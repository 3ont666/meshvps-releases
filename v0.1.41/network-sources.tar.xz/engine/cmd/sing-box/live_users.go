package main

import (
	"encoding/json"
	"errors"
	"io"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"sync"
	"time"

	box "github.com/sagernet/sing-box"
	"github.com/sagernet/sing-box/adapter"
)

var liveUsersSocket string

type userUpdate struct {
	Tag   string          `json:"tag"`
	Users json.RawMessage `json:"users"`
}
type usersRequest struct {
	Version  int          `json:"version"`
	Inbounds []userUpdate `json:"inbounds"`
}
type usersControl struct {
	manager adapter.InboundManager
	mutex   sync.Mutex
}

func (c *usersControl) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	reply := func(status int, ok bool) {
		w.WriteHeader(status)
		_ = json.NewEncoder(w).Encode(map[string]any{"ok": ok, "version": 1})
	}
	if r.URL.Path == "/v1/check" && r.Method == http.MethodPost {
		var req struct {
			Version    int    `json:"version"`
			Tag        string `json:"tag"`
			Credential string `json:"credential"`
		}
		decoder := json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096))
		decoder.DisallowUnknownFields()
		if decoder.Decode(&req) != nil || req.Version != 1 {
			reply(400, false)
			return
		}
		var trailing any
		if decoder.Decode(&trailing) != io.EOF {
			reply(400, false)
			return
		}
		allowed := false
		if inbound, found := c.manager.Get(req.Tag); found {
			if auth, ok := inbound.(interface{ UserAuthorized(string) bool }); ok {
				allowed = auth.UserAuthorized(req.Credential)
			}
		}
		_ = json.NewEncoder(w).Encode(map[string]any{"ok": true, "version": 1, "authorized": allowed})
		return
	}
	if r.URL.Path == "/v1/status" && r.Method == http.MethodGet {
		reply(200, true)
		return
	}
	if r.URL.Path != "/v1/users" || r.Method != http.MethodPost {
		reply(404, false)
		return
	}
	var req usersRequest
	decoder := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1024*1024))
	decoder.DisallowUnknownFields()
	if decoder.Decode(&req) != nil || req.Version != 1 || len(req.Inbounds) == 0 || len(req.Inbounds) > 32 {
		reply(400, false)
		return
	}
	var trailing any
	if decoder.Decode(&trailing) != io.EOF {
		reply(400, false)
		return
	}
	c.mutex.Lock()
	defer c.mutex.Unlock()
	seen := map[string]bool{}
	commits := make([]func(), 0, len(req.Inbounds))
	for _, entry := range req.Inbounds {
		if seen[entry.Tag] {
			reply(400, false)
			return
		}
		seen[entry.Tag] = true
		inbound, exists := c.manager.Get(entry.Tag)
		if !exists {
			reply(400, false)
			return
		}
		updater, supported := inbound.(adapter.LiveUserUpdater)
		if !supported {
			reply(400, false)
			return
		}
		commit, err := updater.PrepareUserUpdate(entry.Users)
		if err != nil {
			reply(400, false)
			return
		}
		commits = append(commits, commit)
	}
	for _, commit := range commits {
		commit()
	}
	reply(200, true)
}

type liveUsersListener struct {
	server   *http.Server
	listener net.Listener
}

func (c *liveUsersListener) Close() error { return c.server.Close() }

func startLiveUsers(instance *box.Box, path string) (io.Closer, error) {
	if !filepath.IsAbs(path) {
		return nil, errors.New("users socket must be absolute")
	}
	if info, err := os.Lstat(path); err == nil {
		if info.Mode()&os.ModeSocket == 0 {
			return nil, errors.New("users socket path already exists")
		}
		conn, dialErr := net.DialTimeout("unix", path, 250*time.Millisecond)
		if dialErr == nil {
			_ = conn.Close()
			return nil, errors.New("users socket already in use")
		}
		if err = os.Remove(path); err != nil {
			return nil, err
		}
	} else if !os.IsNotExist(err) {
		return nil, err
	}
	listener, err := net.Listen("unix", path)
	if err != nil {
		return nil, err
	}
	if err = os.Chmod(path, 0600); err != nil {
		_ = listener.Close()
		return nil, err
	}
	server := &http.Server{Handler: &usersControl{manager: instance.Inbound()}, ReadHeaderTimeout: 2 * time.Second, ReadTimeout: 3 * time.Second, WriteTimeout: 3 * time.Second, IdleTimeout: 3 * time.Second, MaxHeaderBytes: 4096}
	go func() { _ = server.Serve(listener) }()
	return &liveUsersListener{server, listener}, nil
}
